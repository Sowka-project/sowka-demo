<!DOCTYPE html>
        <html lang="pl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Resetuj hasło</title>
            <link rel="stylesheet" type="text/css" href="style/darkstyle.css">
        </head>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'vendor/autoload.php'; // Ścieżka do autoloader PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Połączenie z bazą danych
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sowka";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['email'])) {
        // Obsługa formularza żądania resetowania hasła
        $email = $_POST['email'];

        // Sprawdź, czy e-mail istnieje w bazie danych
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user) {
            $token = bin2hex(random_bytes(50)); // Generowanie tokena
            $expires = time() + 1800; // Token ważny przez 30 minut

            // Aktualizuj token i czas wygaśnięcia w bazie danych
            $stmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_expires = ? WHERE email = ?");
            $stmt->bind_param("sis", $token, $expires, $email);
            $stmt->execute();

            // Wyślij e-mail z linkiem do resetowania hasła przez Gmail SMTP
            $mail = new PHPMailer(true);

            try {
                // Ustawienia serwera SMTP Gmail
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'sowkawiadomosci@gmail.com'; // Tu wprowadź swój e-mail Gmail
                $mail->Password = 'vcnp qorf wvlw roon'; // Tu wprowadź hasło do swojego konta Gmail
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                // Ustawienia wiadomości
                $mail->setFrom('sowkawiadomosci@gmail.com', 'Sowka');
                $mail->addAddress($email);

                $mail->isHTML(false); // Ustaw na true, jeśli chcesz wysyłać wiadomości HTML

                $subject = "Resetowanie hasla";
                $message = "Kliknij ponizszy link, aby zresetowac haslo do Twojego konta:\n\n";
                $message .= "http://localhost/StronaFirmy2.0/reset_password.php?token=$token";

                $mail->Subject = $subject;
                $mail->Body = $message;

                $mail->send();
?>

<body id="login-body">
    <div id="root">
        <main>
            <div id="main-login-box">

                <div id="login-box-banner">
                    <a href="index.php">
                        <img src="img/logo.png" height="60px">
                    </a>
                </div>

                <div id="login-form-box">
                <p class="info">
<?php
                echo "Sprawdź swoją skrzynkę pocztową.";
            } catch (Exception $e) {
                echo "Wystąpił błąd podczas wysyłania e-maila: {$mail->ErrorInfo}";
            }
        } else {
            echo "Nie znaleziono użytkownika z tym adresem e-mail.";
        }
    } elseif (isset($_POST['token']) && isset($_POST['new_password'])) {
        // Obsługa formularza resetowania hasła
        $token = $_POST['token'];
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

        // Sprawdź, czy token istnieje i nie wygasł
        $current_time = time();
        $stmt = $conn->prepare("SELECT * FROM users WHERE reset_token = ? AND reset_expires > ?");
        $stmt->bind_param("si", $token, $current_time);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        ?>
</p>
</div>


</div>
</main>
</div>
<body id="login-body">
    <div id="root">
        <main>
            <div id="main-login-box">

                <div id="login-box-banner">
                    <a href="index.php">
                        <img src="img/logo.png" height="60px">
                    </a>
                </div>

                <div id="login-form-box">
                <p class="info">
        <?php
        if ($user) {
            // Zaktualizuj hasło użytkownika
            $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL WHERE reset_token = ?");
            $stmt->bind_param("ss", $new_password, $token);
            $stmt->execute();

           
            echo "Hasło zostało zaktualizowane.<br><br><a class='link' href='login.php'>Wróć do strony logowania.</a>";
        } else {
            echo "Nieprawidłowy lub wygasły token.<br><br><a class='link' href='login.php'>Wróć do strony logowania.</a>";
        }


    }
} else {
    // Wyświetl odpowiedni formularz na podstawie obecności tokena w URL
    if (isset($_GET['token'])) {
        // Formularz resetowania hasła
        ?>
</p>
</div>


</div>
</main>
</div>
        
        
        <body id="login-body">
    <div id="root">
        <main>
            <div id="main-login-box">

                <div id="login-box-banner">
                    <a href="index.php">
                        <img src="img/logo.png" height="60px">
                    </a>
                </div>

                <div id="login-form-box">
                    <form id="login-form" action="reset_password.php" method="post">
                        <input type="hidden" name="token" value="<?php echo $_GET['token']; ?>">
                        <input class="login-inputs" type="password" name="new_password" placeholder="Nowe hasło" required>
                        <button class="submit" type="submit">Zresetuj hasło</button>
                        
                    </form>
                </div>

                </div>

            </main>

            </div>
            </body>
            </html>
        <?php
    } else {
        // Formularz żądania resetowania hasła
        ?>
        <body id="login-body">
<div id="root">
        <main>
            <div id="main-login-box">

                <div id="login-box-banner">
                    <a href="index.php">
                        <img src="img/logo.png" height="60px">
                    </a>
                </div>


        <div id="login-form-box">
            <form id="login-form" action="reset_password.php" method="post">
                <input class="login-inputs" type="email" name="email" placeholder="Wprowadź swój email" required>
                <button class="submit" type="submit">Resetuj hasło</button>
                <p class="info">Resetowanie hasła może chwilę potrwać.</p>
            </form>
        </div>

        </div>

    </main>

    </div>

        </body>
        </html>
        <?php
    }
}
?>

<?php
// Zamknięcie połączenia
$conn->close();
?>
