<?php
require 'vendor/autoload.php';

// Klucz sekretny Stripe
\Stripe\Stripe::setApiKey('sk_test_4eC39HqLyjWDarjtT1zdp7dc'); // zastąp swoim sekretnym kluczem

// Sekretny klucz webhooka (znajdziesz go w ustawieniach webhooka w Stripe)
$endpoint_secret = 'whsec_...'; // zastąp swoim sekretnym kluczem webhooka

// Odczyt nagłówka podpisu Stripe
$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
$payload = @file_get_contents('php://input');

try {
    $event = \Stripe\Webhook::constructEvent(
        $payload, $sig_header, $endpoint_secret
    );
} catch(\UnexpectedValueException $e) {
    // Invalid payload
    http_response_code(400);
    exit();
} catch(\Stripe\Exception\SignatureVerificationException $e) {
    // Invalid signature
    http_response_code(400);
    exit();
}

// Obsługa różnych typów zdarzeń
if ($event->type == 'checkout.session.completed') {
    $session = $event->data->object;

    // Obsługa sesji zakończonej zakupu
    handleCheckoutSession($session);
} elseif ($event->type == 'invoice.payment_succeeded') {
    $invoice = $event->data->object;

    // Obsługa sukcesu płatności faktury
    handleInvoicePaymentSucceeded($invoice);
}

http_response_code(200);

function handleCheckoutSession($session) {
    // Logika obsługi sesji zakończonej zakupu
    $subscriptionId = $session->subscription;

    // Możesz tutaj zaktualizować bazę danych, dodając nową subskrypcję
    // i datę jej wygaśnięcia
    $expiresAt = date('Y-m-d', strtotime('+1 month')); // zakładamy, że subskrypcja trwa miesiąc

    // Przykład aktualizacji bazy danych
    updateSubscription($subscriptionId, $expiresAt);
}

function handleInvoicePaymentSucceeded($invoice) {
    // Logika obsługi sukcesu płatności faktury
    $subscriptionId = $invoice->subscription;

    // Możesz tutaj zaktualizować bazę danych, dodając nową datę wygaśnięcia subskrypcji
    $expiresAt = date('Y-m-d', strtotime('+1 month')); // zakładamy, że subskrypcja trwa miesiąc

    // Przykład aktualizacji bazy danych
    updateSubscription($subscriptionId, $expiresAt);
}

function updateSubscription($subscriptionId, $expiresAt) {
    // Połączenie z bazą danych (przykład z użyciem PDO)
    $dsn = 'mysql:host=localhost;dbname=twoja_baza_danych';
    $username = 'twoj_uzytkownik';
    $password = 'twoje_haslo';

    try {
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = 'UPDATE users SET subscription = :expiresAt WHERE subscription_id = :subscriptionId';
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':expiresAt' => $expiresAt, ':subscriptionId' => $subscriptionId]);
    } catch (PDOException $e) {
        echo 'Connection failed: ' . $e->getMessage();
    }
}
?>
